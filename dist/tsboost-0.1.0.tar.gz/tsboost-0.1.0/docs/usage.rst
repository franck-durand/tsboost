=====
Usage
=====

To use tsboost in a project::

    import tsboost
