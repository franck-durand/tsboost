=======
History
=======

0.1.0 (2019-06-10)
------------------

* First release on PyPI.
